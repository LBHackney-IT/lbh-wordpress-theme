
<section class="lbh-page-announcement">
  <div class="lbh-content"><?php the_sub_field('featured_message'); ?></div>
</section>
