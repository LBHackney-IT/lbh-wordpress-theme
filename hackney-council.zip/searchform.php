<!-- search -->
<form class="lbh-search" method="get" action="<?php echo home_url(); ?>" role="search">
	<input class="govuk-input lbh-input" type="search" name="s" placeholder="<?php _e( 'To search, type and hit enter.', 'html5blank' ); ?>">
	<button class="govuk-button lbh-button" type="submit" role="button"><?php _e( 'Search', 'html5blank' ); ?></button>
</form>
<!-- /search -->
