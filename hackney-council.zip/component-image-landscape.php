<section class="lbh-image__section">
  <figure class="lbh-image lbh-image--landscape">
    <?php $image = get_sub_field('image_one'); ?>
    <?php include( locate_template( 'component-image.php', false, false ) ); ?>
  </figure>
</section>
