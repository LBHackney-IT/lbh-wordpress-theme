<!-- pagination -->
<div class="lbh-pagination">
	<?php html5wp_pagination(); ?>
</div>
<!-- /pagination -->
